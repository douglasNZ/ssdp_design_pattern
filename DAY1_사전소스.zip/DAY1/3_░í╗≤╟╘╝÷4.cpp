class Base
{
public:
	virtual void foo() {}
	virtual void goo(int) {}
};
class Derived1 : public Base
{
public:
	virtual void fooo() {}
	virtual void goo(double){}
};

int main()
{
}





