// 2_�����Լ�������
class Base
{
public:
	virtual void foo() {}
	virtual void goo(int) {}
};
class Derived : public Base
{
public:

	void fooo() override {}
	virtual void goo(double) override {}
};

int main()
{
}
// 13:00 ~ 




